# CollabApp

MVP source code, CI/CD, payments, hosting, and deployment.
